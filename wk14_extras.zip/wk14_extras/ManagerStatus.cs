﻿public enum ManagerStatus
{
    shutdown,
    Initializing,
    Started
}
